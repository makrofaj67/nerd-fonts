
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit ca226cc63322ee0c6c3faf28e6b2559af6a85fd1
        Author: makrofaj67 <dr.ridvanakman@gmail.com>
        Date:   Tue Dec 17 21:32:37 2024 +0300
        
            Update fontfilenames
