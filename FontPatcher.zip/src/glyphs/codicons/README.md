# Codicons

For more information have a look at the upstream website: https://github.com/microsoft/vscode-codicons

## Source bugs fixed

Glyph 0xEB40 and 0xEB41 are defective in the original font. We fixed that manually.

Version: 0.0.35
