# Font Awesome

For more information have a look at the upstream website: https://github.com/FortAwesome/Font-Awesome

## Custom created font file

The `FontAwesome.otf` here is custom created from the Font Awesome release svgs.

It does NOT contain all icons from 6.5.1!

The helper scripts need to be called in this order (note the individual prerequisites):
* `remix`
* `analyze`
* `generate`

Version: 6.5.1.custom
